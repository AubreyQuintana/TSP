#pragma once
#include <iostream>
#include <string>
using namespace std;


enum degreeType { SOFTWARE, NETWORK, SECURITY }; //3 types of degree programs
static const string degreeTypeStrings[] = { "SOFTWARE", "NETWORK", "SECURITY" };
